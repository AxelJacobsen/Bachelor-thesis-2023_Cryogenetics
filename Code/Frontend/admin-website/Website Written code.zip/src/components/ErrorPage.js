import React from 'react'

function ErrorPage() {
  return (
    <div> PAGE NOT FOUND </div>
  )
}

export default ErrorPage